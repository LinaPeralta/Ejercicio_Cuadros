import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;

public class Main extends PApplet {

	public static void main(String[] args) {
		PApplet.main("Main");
	}

	@Override
	public void settings() {
		size(1000, 800);
	}

	// variables
	int estado;
	int count;

	// ArrayList
	ArrayList<Aliens> aliens;
	
	//objeto
	Aliens alienVerde;
	Aliens alienAzul;
	Aliens alienRojo;

	// Pantallas img
	private PImage PRINCIPAL;
	private PImage INSTRUCCIONES;
	private PImage ESCENARIO;
	private PImage RESUMEN;

	@Override
	public void setup() {

		// FONDOS
		PRINCIPAL = loadImage("data/PRINCIPAL.png");
		INSTRUCCIONES = loadImage("data/INSTRUCCIONES.png");
		ESCENARIO = loadImage("data/ESCENARIO.png");
		RESUMEN = loadImage("data/RESUMEN.png");

		// arraylist
		aliens = new ArrayList<Aliens>();

		//contador
		count = 0;
		
	}

	@Override
	public void draw() {
		background(255);

		// Pantalla Principal
		if (estado == 0) {

			// Fondo
			image(PRINCIPAL, 0, 0);
			imageMode(CORNER);

		}

		// Pantalla Instrucciones
		if (estado == 1) {

			// Fondo
			image(INSTRUCCIONES, 0, 0);
			imageMode(CORNER);

		}

		// Pantalla juego
		if (estado == 2) {
	
			// Fondo
			image(ESCENARIO, 0, 0);
			imageMode(CORNER);
			System.out.println(count);
			
			count++;

			if (count == 60) {
				
				int x = (int) random(200, 800);
			//	int y = (int) random(0, 50);
				int y= -50;
				int velocidad = 2;
				
				aliens.add(new Aliens(this, x, y, velocidad));
				System.out.println(aliens.size());
				count = 0;
			}
			

			// arrayList, pintar y mover los aliens
			for (int i = 0; i < aliens.size(); i++) {
		
				aliens.get(i).pintarVerde(this);
				aliens.get(i).mover();
	
			}
			
			//perder
			for (int i=0; i< aliens.size(); i++) {
		
			if (aliens.get(i).getY() > 800) {
				estado = 3;
			}
			}
      
		}

		// Pantalla Resumen
		if (estado == 3) {

			// Fondo
			image(RESUMEN, 0, 0);
			imageMode(CORNER);

		}

		// System.out.println(mouseX + "," + mouseY);

	}

	@Override
	public void mousePressed() {

		// Boton de jugar principal
		if (dist(mouseX, mouseY, 502, 638) < 30) {
			estado = 1;
		}

		// Boton de jugar instrucciones
		if (dist(mouseX, mouseY, 785, 717) < 30) {
			estado = 2;
		}
		
		//matar aliens
		
		if (estado == 2) {
			for (int i = 0; i < aliens.size(); i++) {

				if (dist(mouseX, mouseY, aliens.get(i).getX(), aliens.get(i).getY()) < 65) {

					aliens.remove(i);
					//contador1++;
				}
			}

		}

	}
	
	//private void removeAliens() { // remove squares

		/*
		 * for (int i=0; i<Aliens.size(); i++) { if (Aliens.size() > 5){
		 * Aliens.remove(i); } }
		 */
	//}
}
