import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;

public class Aliens {
    
	//variables
	int x, y;
	private boolean move;
	int velocidad;

	// Alien
	private PImage ALIENV;
	private PImage ALIENA;
	private PImage ALIENR;

	public Aliens(PApplet app, int x,int y,int velocidad) {
		ALIENV = app.loadImage("data/ALIEN.png");
		ALIENA = app.loadImage("data/ALIEN AZUL.png");
		ALIENR = app.loadImage("data/ALIEN ROJO.png");
		this.x = x;
		this.y = y;
		this.velocidad =  velocidad;
		move = true;
	}

	// PINTAR ALIENS
	public void pintarVerde(PApplet app) {
		app.imageMode(app.CENTER);
		app.image(ALIENV, x, y);
		app.imageMode(app.CORNER);
	}
	
	public void pintarAzul(PApplet app) {
		app.imageMode(app.CENTER);
		app.image(ALIENA, x, y);
		app.imageMode(app.CORNER);
	}
	
	public void pintarRojo(PApplet app) {
		app.imageMode(app.CENTER);
		app.image(ALIENR, x, y);
		app.imageMode(app.CORNER);
	}

	public void mover() {

		if (move) {
			y += velocidad;
		}

		}


	public PImage getALIEN() {
		return ALIENV;
	}

	public void setALIEN(PImage aLIEN) {
		ALIENV = aLIEN;
	}

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public boolean isMove() {
		return move;
	}

	public void setMove(boolean move) {
		this.move = move;
	}

	public int getVelocidad() {
		return velocidad;
	}

	public void setVelocidad(int velocidad) {
		this.velocidad = velocidad;
	}

}