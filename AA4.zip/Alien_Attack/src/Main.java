import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;

public class Main extends PApplet {

	public static void main(String[] args) {
		PApplet.main("Main");
	}

	@Override
	public void settings() {
		size(1000, 800);
	}

	// variables
	private int estado;
	private int countV;
	private int countA;
	private int countR;
	private int min;
	private int seg;
	private int ms;
	private int score;
	private int printMin;
	private int printSeg;
	private int printMs;
	private int printScore;
	//private boolean stop1 = true;
	//private boolean stop2 = true;
	 

	// ArrayLists
	ArrayList<Aliens> aliensV;
	ArrayList<Aliens> aliensA;
	ArrayList<Aliens> aliensR;

	// objeto
	Aliens alienVerde;
	Aliens alienAzul;
	Aliens alienRojo;

	// Pantallas img
	private PImage PRINCIPAL;
	private PImage INSTRUCCIONES;
	private PImage ESCENARIO;
	private PImage RESUMEN;

	@Override
	public void setup() {

		// FONDOS
		PRINCIPAL = loadImage("data/PRINCIPAL.png");
		INSTRUCCIONES = loadImage("data/INSTRUCCIONES.png");
		ESCENARIO = loadImage("data/ESCENARIO.png");
		RESUMEN = loadImage("data/RESUMEN.png");

		// arraylists
		aliensV = new ArrayList<Aliens>();
		aliensA = new ArrayList<Aliens>();
		aliensR = new ArrayList<Aliens>();

		// contador
		countV = 0;
		countA = 0;
		countR = 0;

	}

	
	@Override
	public void draw() {
		background(255);

		// Pantalla Principal
		if (estado == 0) {

			// Fondo
			image(PRINCIPAL, 0, 0);
			imageMode(CORNER);

		}

		// Pantalla Instrucciones
		if (estado == 1) {

			// Fondo
			image(INSTRUCCIONES, 0, 0);
			imageMode(CORNER);

		}

		// Pantalla juego
		if (estado == 2) {

			// Fondo
			image(ESCENARIO, 0, 0);
			imageMode(CORNER);
			System.out.println(countV);

			countV++;

			// aliens verdes
			if (countV == 60) {

				int x = (int) random(200, 800);
				int y = -50;
				int velocidad = 2;

				aliensV.add(new Aliens(this, x, y, velocidad));
				System.out.println(aliensV.size());
				countV = 0;
			}

			// aliens azules
			else if (countA == 120) {

				int x = (int) random(200, 800);
				int y = -50;
				int velocidad = 3;

				aliensA.add(new Aliens(this, x, y, velocidad));
				System.out.println(aliensA.size());
				countA = 0;

			}

			// aliens rojos
			else if (countR == 240) {

				int x = (int) random(200, 800);
				int y = -50;
				int velocidad = 5;

				aliensR.add(new Aliens(this, x, y, velocidad));
				System.out.println(aliensR.size());
				countR = 0;

			}
			

			// arrayList, pintar y mover los aliens verdes
			for (int i = 0; i < aliensV.size(); i++) {

				aliensV.get(i).pintarVerde(this);
				aliensV.get(i).mover();

			}

			// arrayList, pintar y mover los aliens azules
			for (int i = 0; i < aliensA.size(); i++) {

				aliensA.get(i).pintarAzul(this);
				aliensA.get(i).mover();

			}

			// arrayList, pintar y mover los aliens rojos
			for (int i = 0; i < aliensR.size(); i++) {

				aliensR.get(i).pintarRojo(this);
				aliensR.get(i).mover();

			}

			
			//Timer
			textSize(30);
			fill (24,27,55);
			rect (26,20,115,40,10);
			fill (238,249,138);
			noStroke();
			text ("TIME",50,90);
			
			
			if (ms <= 59) {
			//	if (stop1) {
				ms++;
				fill (242,239,160);
				text (min + " : " + seg, 40,50);
				
				//stop1 = false;
			//	}
			} else {
				seg ++;
				ms = 0;
			}
			if (seg <= 59) {
				min=0;
				
			}else {
				min++;
				seg = 0;	
			}
		

		//Puntaje
		
		textSize(30);
		fill (24,27,55);
		rect (860,20,70,40,10);
		fill (238,249,138);
		noStroke();
		text ("PUNTAJE",840,90);
		
		if (score > 0) {
			fill (242,239,160);
			text (score,880,50);
				}
		}
		
		
		// perder verdes
		for (int i = 0; i < aliensV.size(); i++) {

			if (aliensV.get(i).getY() > 800) {
				estado = 3;
				//para imprimir en la pantalla de resumen
				min = printMin;
				seg = printSeg;
				ms = printMs;
				score= printScore;
			}
		}

		// perder azules
		for (int i = 0; i < aliensA.size(); i++) {

			if (aliensA.get(i).getY() > 800) {
				estado = 3;
				//para imprimir en la pantalla de resumen
				min = printMin;
				seg = printSeg;
				ms = printMs;
				score= printScore;
			}
		}

		// perder rojos
		for (int i = 0; i < aliensR.size(); i++) {

			if (aliensR.get(i).getY() > 800) {
				estado = 3;
				//para imprimir en la pantalla de resumen
				min = printMin;
				seg = printSeg;
				ms = printMs;
				score= printScore;
		
			}
		}
		// Pantalla Resumen
		if (estado == 3) {

			// Fondo
			image(RESUMEN, 0, 0);
			imageMode(CORNER);
             
			fill (24,27,55);
			//imprimir timer
			text (printMin + " : " + printSeg, 332,425);
			text ("TIEMPO",320,455);
			
			//imprimir puntaje
			text (printScore, 650,425);
			text ("PUNTAJE",610,455);
	
		} 
		 System.out.println(mouseX + "," + mouseY);
	}

	@Override
	public void mousePressed() {

		// Boton de jugar principal
		if (dist(mouseX, mouseY, 502, 638) < 30) {
			estado = 1;
		}

		// Boton de jugar instrucciones
		if (dist(mouseX, mouseY, 785, 717) < 30) {
			estado = 2;
		}

		// Boton de reintentar
		if (dist(mouseX, mouseY, 508, 581) < 30) {
			estado = 0;

		}

		// matar aliens verdes
		if (estado == 2) {
			for (int i = 0; i < aliensV.size(); i++) {

				if (dist(mouseX, mouseY, aliensV.get(i).getX(), aliensV.get(i).getY()) < 65) {

					aliensV.remove(i);
					score++;
				}
			}

		}

		// matar aliens azules
		if (estado == 2) {
			for (int i = 0; i < aliensA.size(); i++) {

				if (dist(mouseX, mouseY, aliensA.get(i).getX(), aliensA.get(i).getY()) < 65) {

					aliensA.remove(i);
					score++;
				}
			}

		}

		// matar aliens rojos
		if (estado == 2) {
			for (int i = 0; i < aliensR.size(); i++) {

				if (dist(mouseX, mouseY, aliensV.get(i).getX(), aliensR.get(i).getY()) < 65) {

					aliensR.remove(i);
					score++;
				}
			}

		}

	}

}
