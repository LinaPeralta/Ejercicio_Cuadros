import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;

public class AliensV {
    
	//variables
	public int x, y;
	private boolean move;
	public int velocidad;

	// Alien
	private PImage ALIENV;

	public AliensV(PApplet app, int x,int y,int velocidad) {
		ALIENV = app.loadImage("data/ALIEN.png");
		this.x = x;
		this.y = y;
		this.velocidad =  velocidad;
		move = true;
	}

	// PINTAR ALIENS
	public void pintarVerde(PApplet app) {
		app.imageMode(app.CENTER);
		app.image(ALIENV, x, y);
		app.imageMode(app.CORNER);
	}
	
	public void mover() {

		if (move) {
			y += velocidad;
		}

		}



	public PImage getALIENV() {
		return ALIENV;
	}

	public void setALIENV(PImage aLIENV) {
		ALIENV = aLIENV;
	}


	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	public boolean isMove() {
		return move;
	}

	public void setMove(boolean move) {
		this.move = move;
	}

	public int getVelocidad() {
		return velocidad;
	}

	public void setVelocidad(int velocidad) {
		this.velocidad = velocidad;
	}

}