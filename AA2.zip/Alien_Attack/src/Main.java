import java.util.ArrayList;

import processing.core.PApplet;
import processing.core.PImage;

public class Main extends PApplet {

	public static void main(String[] args) {
		PApplet.main("Main");
	}

	@Override
	public void settings() {
		size(1000, 800);
	}

	// variables
	int estado;

	// ArrayList
	ArrayList<Aliens> Aliens;
	
	//objeto
	Aliens aliens;

	// Pantallas img

	private PImage PRINCIPAL;
	private PImage INSTRUCCIONES;
	private PImage ESCENARIO;
	private PImage RESUMEN;

	@Override
	public void setup() {

		// FONDOS
		PRINCIPAL = loadImage("data/PRINCIPAL.png");
		INSTRUCCIONES = loadImage("data/INSTRUCCIONES.png");
		ESCENARIO = loadImage("data/ESCENARIO.png");
		RESUMEN = loadImage("data/RESUMEN.png");

		// arraylist
		Aliens = new ArrayList<Aliens>();

		//frameRate(60);
		//if (frameCount == 60) {
		for (int i = 0; i < 6; i++) { 
			
			int x = (int) random(200, 800);
			int y = (int) random(-10, -1000);
			int velocidad = 2;
			Aliens.add(new Aliens(this, x, y, velocidad));
			//frameCount = 0;
		//}
		}
		
		
	}

	@Override
	public void draw() {
		background(255);

		// Pantalla Principal
		if (estado == 0) {

			// Fondo
			image(PRINCIPAL, 0, 0);
			imageMode(CORNER);

		}

		// Pantalla Instrucciones
		if (estado == 1) {

			// Fondo
			image(INSTRUCCIONES, 0, 0);
			imageMode(CORNER);

		}

		// Pantalla juego
		if (estado == 2) {

			// Fondo
			image(ESCENARIO, 0, 0);
			imageMode(CORNER);

			// arrayList, pintar y mover los aliens
			for (int i = 0; i < Aliens.size(); i++) {

				Aliens.get(i).pintarVerde(this);
				Aliens.get(i).mover();
			
			}
			
			//perder
			
		/*	if (aliens.getY()>800) {
				estado = 3;
			}*/

		}

		// Pantalla Resumen
		if (estado == 3) {

			// Fondo
			image(RESUMEN, 0, 0);
			imageMode(CORNER);

		}

		// System.out.println(mouseX + "," + mouseY);

	}

	@Override
	public void mousePressed() {

		// Boton de jugar principal
		if (dist(mouseX, mouseY, 502, 638) < 30) {
			estado = 1;
		}

		// Boton de jugar instrucciones
		if (dist(mouseX, mouseY, 785, 717) < 30) {
			estado = 2;
		}
		
		//matar aliens
		
		if (estado == 2) {
			for (int i = 0; i < Aliens.size(); i++) {

				if (dist(mouseX, mouseY, Aliens.get(i).getX(), Aliens.get(i).getY()) < 65) {

					Aliens.remove(i);
					//contador1++;
				}
			}

		}

	}
	
	//private void removeAliens() { // remove squares

		/*
		 * for (int i=0; i<Aliens.size(); i++) { if (Aliens.size() > 5){
		 * Aliens.remove(i); } }
		 */
	//}
}
